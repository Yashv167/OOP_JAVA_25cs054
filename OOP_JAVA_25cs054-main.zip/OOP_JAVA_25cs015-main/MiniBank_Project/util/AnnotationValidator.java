package util;

import model.annotation.MaxLength;
import model.annotation.Positive;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/** Reads @Positive and @MaxLength at run time (reflection) and reports every broken rule. */
public class AnnotationValidator {

    public static String[] validate(Object obj) {
        List<String> errors = new ArrayList<>();

        // walk up the class hierarchy so fields of Account are found for a SavingsAccount object
        for (Class<?> c = obj.getClass(); c != null; c = c.getSuperclass()) {
            for (Field field : c.getDeclaredFields()) {
                boolean positive = field.isAnnotationPresent(Positive.class);
                boolean maxLength = field.isAnnotationPresent(MaxLength.class);
                if (!positive && !maxLength) {
                    continue;
                }
                field.setAccessible(true);
                try {
                    Object value = field.get(obj);

                    if (positive && value instanceof Number n && n.longValue() <= 0) {
                        errors.add(field.getName() + " " + field.getAnnotation(Positive.class).message());
                    }
                    if (maxLength && value instanceof String s) {
                        int max = field.getAnnotation(MaxLength.class).value();
                        if (s.length() > max) {
                            errors.add(field.getName() + " must be at most " + max + " characters");
                        }
                    }
                } catch (IllegalAccessException e) {
                    errors.add(field.getName() + " could not be read: " + e.getMessage());
                }
            }
        }
        return errors.toArray(new String[0]);
    }
}
