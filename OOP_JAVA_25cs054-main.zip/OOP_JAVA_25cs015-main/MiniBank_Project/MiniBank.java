import exception.BankException;
import model.Account;
import service.BankService;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

record BankInfo(String name, String branch) { }

enum MenuOption {
    OPEN_ACCOUNT, DEPOSIT, WITHDRAW, TRANSFER, STATEMENT, LIST_ACCOUNTS, BATCH, REPORT, EXIT
}

public class MiniBank {
    private static final Scanner sc = new Scanner(System.in);
    private static final BankService bank = new BankService();

    public static void main(String[] args) {
        BankInfo info = new BankInfo("MiniBank", "Vadodara Main Branch");
        System.out.println("=================================");
        System.out.println(" " + info.name() + " - " + info.branch());
        System.out.println("=================================");

        bank.loadState();   // bring back the accounts saved last time

        MenuOption[] options = MenuOption.values();
        MenuOption selected = null;

        while (selected != MenuOption.EXIT) {
            System.out.println("\n--- Menu ---");
            for (int i = 0; i < options.length; i++) {
                System.out.println((i + 1) + ". " + options[i]);
            }

            int choice;
            try {
                choice = Integer.parseInt(ask("Enter your choice: "));
            } catch (NumberFormatException e) {
                System.out.println("Please enter a number.");
                continue;
            }
            if (choice < 1 || choice > options.length) {
                System.out.println("Invalid choice. Pick 1-" + options.length + ".");
                continue;
            }

            selected = options[choice - 1];

            String message = switch (selected) {
                case OPEN_ACCOUNT  -> openAccount();
                case DEPOSIT       -> deposit();
                case WITHDRAW      -> withdraw();
                case TRANSFER      -> transfer();
                case STATEMENT     -> statement();
                case LIST_ACCOUNTS -> listAccounts();
                case BATCH         -> batch();
                case REPORT        -> report();
                case EXIT          -> "Thank you for using MiniBank. Goodbye!";
            };
            System.out.println(message);
        }

        bank.saveState();   // save everything on exit
    }

    private static String openAccount() {
        String choice = ask("Account type (1 = Savings, 2 = Current, 3 = Fixed deposit): ");
        String type;
        if (choice.equals("1")) {
            type = "SAVINGS";
        } else if (choice.equals("2")) {
            type = "CURRENT";
        } else if (choice.equals("3")) {
            type = "FD";
        } else {
            return "Error: choose 1, 2 or 3.";
        }
        try {
            String owner = ask("Owner name: ");
            String mobile = ask("Mobile number: ");
            long opening = Long.parseLong(ask("Opening balance (Rs.): "));
            Account account = bank.openAccount(type, owner, mobile, opening);
            return "Account opened: " + account.getAccountNumber();
        } catch (BankException e) {
            return "Error: " + e.getMessage();
        } catch (NumberFormatException e) {
            return "Error: please enter a whole number.";
        }
    }

    private static String deposit() {
        try {
            String number = ask("Account number: ");
            long amount = Long.parseLong(ask("Amount (Rs.): "));
            bank.deposit(number, amount);
            return "Deposit successful.";
        } catch (BankException e) {
            return "Error: " + e.getMessage();
        } catch (NumberFormatException e) {
            return "Error: please enter a whole number.";
        }
    }

    private static String withdraw() {
        try {
            String number = ask("Account number: ");
            long amount = Long.parseLong(ask("Amount (Rs.): "));
            bank.withdraw(number, amount);
            return "Withdrawal successful.";
        } catch (BankException e) {
            return "Error: " + e.getMessage();
        } catch (NumberFormatException e) {
            return "Error: please enter a whole number.";
        }
    }

    private static String transfer() {
        try {
            String from = ask("From account: ");
            String to = ask("To account: ");
            long amount = Long.parseLong(ask("Amount (Rs.): "));
            bank.transfer(from, to, amount);
            return "Transfer successful.";
        } catch (BankException e) {
            return "Error: " + e.getMessage();
        } catch (NumberFormatException e) {
            return "Error: please enter a whole number.";
        }
    }

    private static String statement() {
        try {
            return bank.statement(ask("Account number: "));
        } catch (BankException e) {
            return "Error: " + e.getMessage();
        }
    }

    private static String listAccounts() {
        List<Account> accounts = bank.listAccounts();
        if (accounts.isEmpty()) {
            return "No accounts yet.";
        }
        StringBuilder sb = new StringBuilder("--- Accounts ---");
        for (Account a : accounts) {
            sb.append("\n").append(a.getAccountNumber()).append(" | ").append(a.getOwnerName())
              .append(" | ").append(a.getClass().getSimpleName())
              .append(" | Rs. ").append(a.getBalance());
        }
        return sb.toString();
    }

    // Sends 10 deposits of Rs. 100 and 5 withdrawals of Rs. 50 to the thread pool
    private static String batch() {
        String number = ask("Account number for the batch: ").toUpperCase();
        List<String> lines = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            lines.add("DEPOSIT " + number + " 100");
        }
        for (int i = 0; i < 5; i++) {
            lines.add("WITHDRAW " + number + " 50");
        }
        return bank.processBatch(lines);
    }

    private static String report() {
        try {
            return bank.report();
        } catch (IOException e) {
            return "Could not create the report: " + e.getMessage();
        }
    }

    private static String ask(String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }
}
