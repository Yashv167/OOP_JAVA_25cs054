import exception.BankException;
import exception.InsufficientFundsException;
import exception.InvalidAmountException;
import model.Account;
import model.CurrentAccount;
import model.FixedDepositAccount;
import model.SavingsAccount;
import org.junit.jupiter.api.Test;
import service.AccountWorker;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

public class BankTests {

    @Test
    void depositIncreasesBalance() throws BankException {
        Account account = new SavingsAccount("Test", 1000, 0);
        account.deposit(500);
        assertEquals(1500L, account.getBalance());
    }

    @Test
    void withdrawalOverTheLimitThrowsAndKeepsBalance() {
        Account account = new SavingsAccount("Test", 1000, 500);   // only Rs. 500 may be withdrawn
        assertThrows(InsufficientFundsException.class, () -> account.withdraw(800));
        assertEquals(1000L, account.getBalance());
    }

    @Test
    void nonPositiveAmountsAreRejected() {
        Account account = new CurrentAccount("Test", 1000, 0);
        assertThrows(InvalidAmountException.class, () -> account.deposit(0));
        assertThrows(InvalidAmountException.class, () -> account.withdraw(-5));
    }

    @Test
    void lockedFixedDepositCannotBeWithdrawn() {
        Account account = new FixedDepositAccount("Test", 10000);
        assertThrows(InsufficientFundsException.class, () -> account.withdraw(100));
    }

    @Test
    void manyConcurrentDepositsKeepTheBalanceCorrect() throws InterruptedException {
        Account account = new CurrentAccount("Test", 0, 0);
        int threadCount = 8;
        int depositsPerThread = 10_000;

        Thread[] threads = new Thread[threadCount];
        for (int i = 0; i < threadCount; i++) {
            threads[i] = new Thread(new AccountWorker(account, depositsPerThread, 1, true));
            threads[i].start();
        }
        for (Thread t : threads) {
            t.join();
        }
        assertEquals((long) threadCount * depositsPerThread, account.getBalance());
    }
}
