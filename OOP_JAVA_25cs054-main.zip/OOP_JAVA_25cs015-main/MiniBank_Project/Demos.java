import exception.AccountNotFoundException;
import exception.BankException;
import exception.InsufficientFundsException;
import exception.InvalidAmountException;
import model.Account;
import model.Command;
import model.CurrentAccount;
import model.Customer;
import model.FixedDepositAccount;
import model.Premium;
import model.SavingsAccount;
import model.TransactionType;
import model.WithdrawRule;
import service.AccountStore;
import service.AccountWorker;
import service.CommandParser;
import service.DeadlockDemo;
import service.ReportGenerator;
import service.StatePersister;
import service.StatementFormatter;
import service.TransactionBuffer;
import service.TransactionLog;
import service.TransactionProcessor;
import service.TransactionSession;
import util.AnnotationValidator;
import util.Repository;
import util.Validator;
import static util.Validator.isValidMobile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;

/**
 * One demo per practical (2 to 13), so each lab's output can be shown on its own.
 *   java -cp out Demos        runs every demo
 *   java -cp out Demos 9      runs only practical 9
 *   java -cp out Demos 7 8    runs practicals 7 and 8
 * (Practicals 1 and 14 are the MiniBank menu itself.)
 */
public class Demos {

    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            for (int p = 2; p <= 13; p++) {
                run(p);
            }
        } else {
            for (String arg : args) {
                run(Integer.parseInt(arg));
            }
        }
    }

    private static void run(int practical) throws Exception {
        System.out.println("\n################ PRACTICAL " + practical + " ################");
        switch (practical) {
            case 2  -> demo2();
            case 3  -> demo3();
            case 4  -> demo4();
            case 5  -> demo5();
            case 6  -> demo6();
            case 7  -> demo7();
            case 8  -> demo8();
            case 9  -> demo9();
            case 10 -> demo10();
            case 11 -> demo11();
            case 12 -> demo12();
            case 13 -> demo13();
            default -> System.out.println("No demo for practical " + practical
                    + " (1 and 14 are the MiniBank menu).");
        }
    }

    private static Account[] threeAccounts() {
        return new Account[] {
            new SavingsAccount("Riya Shah", 5000, 1000),
            new CurrentAccount("Amit Patel", 1000, 2000),
            new FixedDepositAccount("Neha Mehta", 10000)
        };
    }

    // ---------------- Practical 2: Customer and Account ----------------
    private static void demo2() {
        Account[] accounts = threeAccounts();
        try {
            accounts[0].deposit(2000);
            accounts[0].withdraw(3000);
            accounts[2].deposit(750);
            accounts[1].withdraw(5000);          // over the overdraft limit, throws
        } catch (BankException e) {
            System.out.println("Stopped: " + e.getMessage());
        }
        System.out.println("--- Account Balances ---");
        for (Account a : accounts) {
            System.out.println(a.getAccountNumber() + " | " + a.getOwnerName() + " | Rs. " + a.getBalance());
        }
        Customer c1 = new Customer("Riya Shah", "riya@example.com", "9876543210",
                new Customer.Address("12 Alkapuri", "Vadodara", "390007"));
        Customer c2 = new Customer("Amit Patel", "amit@example.com", "9123456780",
                new Customer.Address("5 Fatehgunj", "Vadodara", "390002"));
        System.out.println("Customers: " + c1.getCustomerId() + ", " + c2.getCustomerId());
    }

    // ---------------- Practical 3: toString, equals, instanceof, clone ----------------
    private static void demo3() {
        Account[] accounts = threeAccounts();
        System.out.println("--- toString ---");
        for (Account a : accounts) {
            System.out.println(a);
        }
        Account alias = accounts[0];
        System.out.println("--- equals ---");
        System.out.println("accounts[0].equals(accounts[1]): " + accounts[0].equals(accounts[1]));
        System.out.println("accounts[0].equals(alias): " + accounts[0].equals(alias));

        Object obj = accounts[2];
        System.out.println("--- instanceof ---");
        System.out.println("obj instanceof Account: " + (obj instanceof Account));
        System.out.println("obj instanceof Customer: " + (obj instanceof Customer));

        Customer c1 = new Customer("Riya Shah", "riya@example.com", "9876543210",
                new Customer.Address("12 Alkapuri", "Vadodara", "390007"));
        Customer copy = c1.clone();
        System.out.println("--- clone ---");
        System.out.println("Same id: " + copy.getCustomerId().equals(c1.getCustomerId()));
        System.out.println("Same object: " + (copy == c1));
        System.out.println("City: " + copy.getAddress().getCity());
    }

    // ---------------- Practical 4: validation, parser, statement ----------------
    private static void demo4() {
        System.out.println("Mobile 9876543210: " + isValidMobile("9876543210"));
        System.out.println("Mobile 12345: " + isValidMobile("12345"));
        System.out.println("Email riya@example.com: " + Validator.isValidEmail("riya@example.com"));
        System.out.println("Email riya@com: " + Validator.isValidEmail("riya@com"));
        System.out.println("PAN ABCDE1234F: " + Validator.isValidPan("ABCDE1234F"));
        System.out.println("PAN abcde1234: " + Validator.isValidPan("abcde1234"));
        System.out.println("IFSC SBIN0001234: " + Validator.isValidIfsc("SBIN0001234"));
        System.out.println("IFSC SBIN1001234: " + Validator.isValidIfsc("SBIN1001234"));

        Command cmd = CommandParser.parse("DEPOSIT AC0001 500");
        System.out.println("--- Command Parser ---");
        System.out.println("Type: " + cmd.type());
        System.out.println("Account: " + cmd.accountNumber());
        System.out.println("Amount: " + cmd.amount());

        System.out.println("--- Statement ---");
        System.out.println(StatementFormatter.buildStatement(new SavingsAccount("Riya Shah", 4000, 500)));
    }

    // ---------------- Practical 5: run-time polymorphism ----------------
    private static void demo5() {
        Account[] accounts = threeAccounts();
        for (Account a : accounts) {
            System.out.println(a.getAccountNumber() + " -> interest " + a.interestRate()
                    + "% (" + a.getClass().getSimpleName() + ")");
            if (a instanceof SavingsAccount s) {
                System.out.println("   Savings minimum balance: Rs. " + s.getMinBalance());
            }
            System.out.println("   can withdraw Rs. 500: " + a.canWithdraw(500));
        }
    }

    // ---------------- Practical 6: interfaces ----------------
    private static void demo6() {
        for (Account a : threeAccounts()) {
            System.out.println(a.getAccountNumber() + " yearly interest: Rs. " + a.yearlyInterest()
                    + (a instanceof Premium ? "  (Premium account)" : ""));
        }
        Account account = new SavingsAccount("Test User", 3000, 500);

        WithdrawRule anonymousRule = new WithdrawRule() {
            @Override
            public boolean allow(Account acc, long amount) {
                return amount <= acc.getBalance() / 2;
            }
        };
        WithdrawRule lambdaRule = (acc, amount) -> amount <= acc.getBalance() / 2;

        System.out.println("Anonymous class, Rs. 1000: " + anonymousRule.allow(account, 1000));
        System.out.println("Lambda, Rs. 2000: " + lambdaRule.allow(account, 2000));
    }

    // ---------------- Practical 7: annotations + reflection ----------------
    private static void demo7() {
        Account bad = new SavingsAccount("An owner name that is definitely longer than thirty characters", -500, 100);
        String[] errors = AnnotationValidator.validate(bad);
        System.out.println("Errors found for the bad account: " + errors.length);
        for (String error : errors) {
            System.out.println("  ERROR: " + error);
        }
        Account good = new SavingsAccount("Good User", 2000, 500);
        System.out.println("Errors found for a good account: " + AnnotationValidator.validate(good).length);
    }

    // ---------------- Practical 8: exceptions ----------------
    private static void demo8() {
        Account a = new SavingsAccount("Exception Demo", 3000, 500);
        Account b = new CurrentAccount("Receiver", 0, 0);

        try {
            a.withdraw(5000);
        } catch (InsufficientFundsException e) {
            System.out.println("Withdraw failed: " + e.getMessage() + " (shortfall field = " + e.getShortfall() + ")");
        } catch (InvalidAmountException e) {
            System.out.println("Invalid amount: " + e.getMessage());
        } finally {
            System.out.println("finally: withdrawal attempt completed");
        }

        try {
            a.deposit(-100);
        } catch (InvalidAmountException e) {
            System.out.println("Deposit failed: " + e.getMessage());
        }

        try {
            a.transfer(b, 1000);
            System.out.println("Transfer ok. Sender Rs. " + a.getBalance() + ", receiver Rs. " + b.getBalance());
            a.transfer(b, 100000);
        } catch (BankException e) {
            System.out.println("Caught the re-thrown exception: " + e.getMessage());
        }

        try {
            throw new AccountNotFoundException("AC9999");
        } catch (AccountNotFoundException e) {
            System.out.println("Lookup failed: " + e.getMessage());
        }

        try (TransactionSession session = new TransactionSession("demo")) {
            session.log("doing some work inside try-with-resources");
        }
    }

    // ---------------- Practical 9: threads and race condition ----------------
    private static void demo9() throws InterruptedException {
        System.out.println("--- WITHOUT synchronization (race condition) ---");
        long unsafe = runWorkers(false);
        System.out.println("Expected 1000000, got " + unsafe + (unsafe == 1_000_000 ? "" : "   <-- WRONG"));

        System.out.println("--- WITH synchronized deposit() ---");
        long safe = runWorkers(true);
        System.out.println("Expected 1000000, got " + safe);
    }

    private static long runWorkers(boolean safe) throws InterruptedException {
        Account account = new SavingsAccount("Race Test", 0, 0);
        Thread[] threads = new Thread[10];
        for (int i = 0; i < threads.length; i++) {
            threads[i] = new Thread(new AccountWorker(account, 100_000, 1, safe), "Worker-" + (i + 1));
        }
        System.out.println("Before start: " + threads[0].getName() + " is " + threads[0].getState());
        for (Thread t : threads) {
            t.start();
        }
        System.out.println("After start : " + threads[0].getName() + " is " + threads[0].getState());
        for (Thread t : threads) {
            t.join();
        }
        System.out.println("After join  : " + threads[0].getName() + " is " + threads[0].getState());
        return account.getBalance();
    }

    // ---------------- Practical 10: thread pool, producer-consumer, deadlock ----------------
    private static void demo10() throws Exception {
        System.out.println("--- Thread pool (4 threads) ---");
        TransactionProcessor processor = new TransactionProcessor();
        Account account = new SavingsAccount("Pool Test", 1000, 0);
        processor.register(account);
        for (int i = 0; i < 15; i++) {
            processor.submit(processor.taskFor(new Command(TransactionType.DEPOSIT, account.getAccountNumber(), 100)));
        }
        for (int i = 0; i < 5; i++) {
            processor.submit(processor.taskFor(new Command(TransactionType.WITHDRAW, account.getAccountNumber(), 50)));
        }
        processor.stop();
        System.out.println("1000 + 15 x 100 - 5 x 50 = " + account.getBalance() + " (expected 2250)");
        System.out.println("First results: ");
        for (String result : processor.getResults().subList(0, 3)) {
            System.out.println("  " + result);
        }

        System.out.println("--- Producer / consumer with wait() and notify() ---");
        TransactionBuffer buffer = new TransactionBuffer(3);
        Account target = new SavingsAccount("Buffer Test", 0, 0);

        Thread producer = new Thread(() -> {
            try {
                for (int i = 1; i <= 8; i++) {
                    buffer.put(new Command(TransactionType.DEPOSIT, target.getAccountNumber(), 100));
                    System.out.println("Produced #" + i);
                }
                buffer.put(TransactionBuffer.STOP);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }, "Producer");

        Thread consumer = new Thread(() -> {
            int n = 0;
            try {
                while (true) {
                    Command command = buffer.take();
                    if (command == TransactionBuffer.STOP) {
                        break;
                    }
                    target.deposit(command.amount());
                    System.out.println("      Consumed #" + (++n));
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } catch (BankException e) {
                System.out.println(e.getMessage());
            }
        }, "Consumer");

        producer.start();
        consumer.start();
        producer.join();
        consumer.join();
        System.out.println("Buffer test balance: " + target.getBalance() + " (expected 800)");

        System.out.println("--- Deadlock and its fix ---");
        DeadlockDemo.runDemo();
    }

    // ---------------- Practical 11: persistence and reports ----------------
    private static void demo11() throws Exception {
        Account[] accounts = threeAccounts();
        Path dataFile = Path.of("data", "demo-accounts.dat");
        StatePersister.save(accounts, dataFile);
        Account[] loaded = StatePersister.load(dataFile);
        System.out.println("--- Accounts after save and reload ---");
        for (Account a : loaded) {
            System.out.println(a);
        }

        Path logs = Path.of("demo-logs");
        Path logFile = logs.resolve("day1.log");
        Files.deleteIfExists(logFile);
        TransactionLog.append(logFile, "DEPOSIT," + accounts[0].getAccountNumber() + ",2000");
        TransactionLog.append(logFile, "DEPOSIT," + accounts[2].getAccountNumber() + ",750");
        TransactionLog.append(logFile, "WITHDRAW," + accounts[0].getAccountNumber() + ",3000");
        TransactionLog.append(logFile, "TRANSFER," + accounts[0].getAccountNumber() + "," + accounts[1].getAccountNumber() + ",500");

        System.out.println(ReportGenerator.generate(logs, Path.of("demo-report.txt")));
    }

    // ---------------- Practical 12: collections ----------------
    private static void demo12() {
        AccountStore store = new AccountStore();
        for (Account a : threeAccounts()) {
            store.add(a);
        }
        store.add(new SavingsAccount("Kiran Desai", 2500, 500));

        System.out.println("--- Sorted by balance (Comparator) ---");
        for (Account a : store.sortedByBalance()) {
            System.out.println(a);
        }

        ArrayList<Account> byNumber = store.getAll();
        Collections.sort(byNumber);   // uses Account.compareTo (account number)
        System.out.println("--- Sorted by account number (Comparable) ---");
        for (Account a : byNumber) {
            System.out.println(a.getAccountNumber());
        }

        System.out.println("--- Transaction history (ArrayList) ---");
        for (String entry : store.getHistory()) {
            System.out.println("  " + entry);
        }

        TransactionProcessor processor = new TransactionProcessor();   // keeps accounts in a ConcurrentHashMap
        processor.register(byNumber.get(0));
        System.out.println("Thread-safe lookup: " + processor.get(byNumber.get(0).getAccountNumber()));
        processor.stop();
    }

    // ---------------- Practical 13: generic repository ----------------
    private static void demo13() {
        Repository<Account> repository = new Repository<>();
        Account a = new SavingsAccount("Riya Shah", 5000, 1000);
        Account b = new CurrentAccount("Amit Patel", 1000, 2000);
        Account c = new FixedDepositAccount("Neha Mehta", 10000);
        repository.saveAll(a, b, c);

        System.out.println("findById(" + b.getAccountNumber() + "): " + repository.findById(b.getAccountNumber()));
        System.out.println("--- findAll ---");
        for (Account account : repository.findAll()) {
            System.out.println(account);
        }
        System.out.println("delete(" + c.getAccountNumber() + "): " + repository.delete(c.getAccountNumber()));
        System.out.println("Accounts left: " + repository.findAll().size());

        System.out.println("average of 10, 20, 30 = " + Repository.average(new Integer[] {10, 20, 30}));
        System.out.println("average of 1.5, 2.5   = " + Repository.average(new Double[] {1.5, 2.5}));
    }
}
