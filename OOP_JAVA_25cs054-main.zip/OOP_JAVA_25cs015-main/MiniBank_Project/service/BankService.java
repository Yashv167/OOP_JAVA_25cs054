package service;

import exception.AccountNotFoundException;
import exception.BankException;
import exception.InvalidAmountException;
import model.Account;
import model.Command;
import model.CurrentAccount;
import model.FixedDepositAccount;
import model.SavingsAccount;
import util.Repository;
import util.Validator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collections;
import java.util.List;

public class BankService {
    private final Repository<Account> repository = new Repository<>();
    private final Path logFile = TransactionLog.DEFAULT_FILE;
    private final Path dataFile = Path.of("data", "accounts.dat");

    public Account openAccount(String type, String ownerName, String mobile, long openingBalance) throws BankException {
        if (ownerName == null || ownerName.isBlank()) {
            throw new BankException("Owner name is required");
        }
        if (!Validator.isValidMobile(mobile)) {
            throw new BankException("Invalid mobile number: " + mobile);
        }
        if (openingBalance < 0) {
            throw new InvalidAmountException("Opening balance cannot be negative");
        }

        Account account;
        if (type.equals("SAVINGS")) {
            account = new SavingsAccount(ownerName, openingBalance, 500);
        } else if (type.equals("CURRENT")) {
            account = new CurrentAccount(ownerName, openingBalance, 5000);
        } else if (type.equals("FD")) {
            account = new FixedDepositAccount(ownerName, openingBalance);
        } else {
            throw new BankException("Unknown account type: " + type);
        }

        repository.save(account);
        log("OPEN," + account.getAccountNumber() + "," + openingBalance);
        return account;
    }

    public void deposit(String accountNumber, long amount) throws BankException {
        Account account = find(accountNumber);
        account.deposit(amount);
        log("DEPOSIT," + account.getAccountNumber() + "," + amount);
    }

    public void withdraw(String accountNumber, long amount) throws BankException {
        Account account = find(accountNumber);
        account.withdraw(amount);
        log("WITHDRAW," + account.getAccountNumber() + "," + amount);
    }

    public void transfer(String fromAccount, String toAccount, long amount) throws BankException {
        Account from = find(fromAccount);
        Account to = find(toAccount);
        from.transfer(to, amount);
        log("TRANSFER," + from.getAccountNumber() + "," + to.getAccountNumber() + "," + amount);
    }

    public String statement(String accountNumber) throws BankException {
        return StatementFormatter.buildStatement(find(accountNumber));
    }

    public List<Account> listAccounts() {
        List<Account> list = repository.findAll();
        Collections.sort(list);   // by account number
        return list;
    }

    // Runs lines such as "DEPOSIT AC0001 500" on the thread pool
    public String processBatch(List<String> commandLines) {
        TransactionProcessor processor = new TransactionProcessor();
        for (Account account : repository.findAll()) {
            processor.register(account);
        }
        for (String line : commandLines) {
            processor.submit(processor.taskFor(CommandParser.parse(line)));
        }
        processor.stop();   // waits until every task is finished

        for (Command command : processor.getSucceeded()) {
            log(command.type() + "," + command.accountNumber() + "," + command.amount());
        }

        StringBuilder sb = new StringBuilder();
        for (String result : processor.getResults()) {
            sb.append(result).append("\n");
        }
        sb.append(processor.getSucceeded().size()).append(" of ")
          .append(commandLines.size()).append(" transactions succeeded.");
        return sb.toString();
    }

    public String report() throws IOException {
        return ReportGenerator.generate(Path.of("logs"), Path.of("report.txt"));
    }

    public void loadState() {
        if (!Files.exists(dataFile)) {
            return;
        }
        try {
            Account[] loaded = StatePersister.load(dataFile);
            for (Account account : loaded) {
                repository.save(account);
            }
            System.out.println("Loaded " + loaded.length + " saved account(s).");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Could not load saved accounts: " + e.getMessage());
        }
    }

    public void saveState() {
        try {
            Account[] all = repository.findAll().toArray(new Account[0]);
            StatePersister.save(all, dataFile);
            System.out.println("Saved " + all.length + " account(s).");
        } catch (IOException e) {
            System.out.println("Could not save accounts: " + e.getMessage());
        }
    }

    private Account find(String accountNumber) throws AccountNotFoundException {
        String id = accountNumber.trim().toUpperCase();
        Account account = repository.findById(id);
        if (account == null) {
            throw new AccountNotFoundException(id);
        }
        return account;
    }

    private void log(String line) {
        try {
            TransactionLog.append(logFile, line);
        } catch (IOException e) {
            System.out.println("Could not write the log: " + e.getMessage());
        }
    }
}
