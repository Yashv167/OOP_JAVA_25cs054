package service;

/** Small AutoCloseable used to demonstrate try-with-resources. */
public class TransactionSession implements AutoCloseable {
    private final String name;

    public TransactionSession(String name) {
        this.name = name;
        System.out.println("[session] opened: " + name);
    }

    public void log(String message) {
        System.out.println("[session " + name + "] " + message);
    }

    @Override
    public void close() {
        System.out.println("[session] closed: " + name);
    }
}
