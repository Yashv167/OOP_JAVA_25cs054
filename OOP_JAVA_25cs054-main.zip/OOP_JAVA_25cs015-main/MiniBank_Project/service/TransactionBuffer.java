package service;

import model.Command;
import model.TransactionType;

/** Fixed-size shared buffer: producer calls put(), consumer calls take(), using wait()/notify. */
public class TransactionBuffer {
    /** Special command that tells the consumer to stop. */
    public static final Command STOP = new Command(TransactionType.DEPOSIT, "STOP", 0);

    private final Command[] buffer;
    private final Object lock = new Object();
    private int count = 0;
    private int putIndex = 0;
    private int takeIndex = 0;

    public TransactionBuffer(int capacity) {
        this.buffer = new Command[capacity];
    }

    public void put(Command command) throws InterruptedException {
        synchronized (lock) {
            while (count == buffer.length) {
                lock.wait();            // buffer full: wait for the consumer
            }
            buffer[putIndex] = command;
            putIndex = (putIndex + 1) % buffer.length;
            count++;
            lock.notifyAll();           // wake the consumer
        }
    }

    public Command take() throws InterruptedException {
        synchronized (lock) {
            while (count == 0) {
                lock.wait();            // buffer empty: wait for the producer
            }
            Command command = buffer[takeIndex];
            takeIndex = (takeIndex + 1) % buffer.length;
            count--;
            lock.notifyAll();           // wake the producer
            return command;
        }
    }
}
