package service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

/** Append-only log. One line per transaction, e.g. DEPOSIT,AC0001,500 */
public class TransactionLog {
    public static final Path DEFAULT_FILE = Path.of("logs", "transactions.log");

    public static synchronized void append(Path file, String line) throws IOException {
        Path parent = file.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        Files.write(file, List.of(line), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }
}
