package service;

import model.Account;

public class StatementFormatter {
    public static String buildStatement(Account account) {
        StringBuilder sb = new StringBuilder();
        sb.append("===== ACCOUNT STATEMENT =====\n");
        sb.append("Account No : ").append(account.getAccountNumber()).append("\n");
        sb.append("Owner      : ").append(account.getOwnerName()).append("\n");
        sb.append("Type       : ").append(account.getClass().getSimpleName()).append("\n");
        sb.append("Status     : ").append(account.isActive() ? "ACTIVE" : "INACTIVE").append("\n");
        sb.append("Balance    : Rs. ").append(account.getBalance()).append("\n");
        sb.append("Interest   : ").append(account.interestRate()).append("% p.a.\n");
        sb.append("=============================");
        return sb.toString();
    }
}
