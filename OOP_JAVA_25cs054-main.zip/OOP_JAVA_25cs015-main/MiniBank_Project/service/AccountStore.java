package service;

import model.Account;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;

public class AccountStore {
    private final HashMap<String, Account> accounts = new HashMap<>();
    private final ArrayList<String> history = new ArrayList<>();

    public void add(Account account) {
        accounts.put(account.getAccountNumber(), account);
        history.add("ADDED " + account.getAccountNumber() + " (" + account.getOwnerName() + ")");
    }

    public Account get(String accountNumber) {
        return accounts.get(accountNumber);
    }

    public ArrayList<Account> getAll() {
        return new ArrayList<>(accounts.values());
    }

    public void record(String entry) {
        history.add(entry);
    }

    public ArrayList<String> getHistory() {
        return history;
    }

    public ArrayList<Account> sortedByBalance() {
        ArrayList<Account> list = new ArrayList<>(accounts.values());
        Comparator<Account> byBalance = (a, b) -> Long.compare(a.getBalance(), b.getBalance());
        list.sort(byBalance);
        return list;
    }
}
