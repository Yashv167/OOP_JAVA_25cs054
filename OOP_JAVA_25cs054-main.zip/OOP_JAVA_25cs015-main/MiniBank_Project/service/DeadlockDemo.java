package service;

import exception.BankException;
import model.Account;
import model.SavingsAccount;

/** Shows a deadlock (opposite lock order) and its fix (always lock the smaller account number first). */
public class DeadlockDemo {

    public static void unsafeTransfer(Account from, Account to, long amount) {
        synchronized (from) {
            pause(100);                       // give the other thread time to lock its first account
            synchronized (to) {
                move(from, to, amount);
            }
        }
    }

    public static void safeTransfer(Account from, Account to, long amount) {
        Account first = from.getAccountNumber().compareTo(to.getAccountNumber()) < 0 ? from : to;
        Account second = (first == from) ? to : from;
        synchronized (first) {
            pause(100);
            synchronized (second) {
                move(from, to, amount);
            }
        }
    }

    private static void move(Account from, Account to, long amount) {
        try {
            from.withdraw(amount);
            to.deposit(amount);
        } catch (BankException e) {
            System.out.println("Transfer failed: " + e.getMessage());
        }
    }

    private static void pause(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public static void runDemo() throws InterruptedException {
        System.out.println("--- Opposite lock order (this deadlocks) ---");
        Account a = new SavingsAccount("Deadlock A", 5000, 0);
        Account b = new SavingsAccount("Deadlock B", 5000, 0);
        Thread t1 = new Thread(() -> unsafeTransfer(a, b, 100), "A-to-B");
        Thread t2 = new Thread(() -> unsafeTransfer(b, a, 100), "B-to-A");
        t1.setDaemon(true);   // daemon threads so the stuck pair cannot keep the program alive
        t2.setDaemon(true);
        t1.start();
        t2.start();
        t1.join(2000);
        t2.join(2000);
        if (t1.isAlive() && t2.isAlive()) {
            System.out.println("DEADLOCK: " + t1.getName() + " is " + t1.getState() + ", "
                    + t2.getName() + " is " + t2.getState() + " - each waits for the other's lock");
        }

        System.out.println("--- Consistent lock order (fixed) ---");
        Account c = new SavingsAccount("Safe C", 5000, 0);
        Account d = new SavingsAccount("Safe D", 5000, 0);
        Thread t3 = new Thread(() -> safeTransfer(c, d, 100), "C-to-D");
        Thread t4 = new Thread(() -> safeTransfer(d, c, 300), "D-to-C");
        t3.start();
        t4.start();
        t3.join();
        t4.join();
        System.out.println("Both transfers completed. C = Rs. " + c.getBalance()
                + ", D = Rs. " + d.getBalance());
    }
}
