package service;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;

public class ReportGenerator {

    /** Reads every log file in logsDir, totals deposits and withdrawals, writes the summary to reportFile. */
    public static String generate(Path logsDir, Path reportFile) throws IOException {
        long totalDeposits = 0;
        long totalWithdrawals = 0;
        long transfers = 0;
        int files = 0;

        StringBuilder report = new StringBuilder();
        report.append("===== END-OF-DAY REPORT =====\n");

        if (Files.isDirectory(logsDir)) {
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(logsDir)) {
                for (Path file : stream) {
                    if (!Files.isRegularFile(file)) {
                        continue;
                    }
                    files++;
                    BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
                    report.append("File: ").append(file.getFileName())
                          .append(" | ").append(attrs.size()).append(" bytes")
                          .append(" | modified ").append(attrs.lastModifiedTime()).append("\n");

                    try (BufferedReader reader = Files.newBufferedReader(file)) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            String[] parts = line.split(",");
                            if (parts.length < 3) {
                                continue;
                            }
                            try {
                                switch (parts[0].trim()) {
                                    case "DEPOSIT"  -> totalDeposits += Long.parseLong(parts[2].trim());
                                    case "WITHDRAW" -> totalWithdrawals += Long.parseLong(parts[2].trim());
                                    case "TRANSFER" -> transfers++;
                                    default -> { }
                                }
                            } catch (NumberFormatException e) {
                                // skip a damaged line
                            }
                        }
                    }
                }
            }
        }

        if (files == 0) {
            report.append("(no log files found yet)\n");
        }
        report.append("Total deposits    : Rs. ").append(totalDeposits).append("\n");
        report.append("Total withdrawals : Rs. ").append(totalWithdrawals).append("\n");
        report.append("Transfers         : ").append(transfers).append("\n");
        report.append("=============================");

        Files.writeString(reportFile, report.toString());
        return report.toString();
    }
}
