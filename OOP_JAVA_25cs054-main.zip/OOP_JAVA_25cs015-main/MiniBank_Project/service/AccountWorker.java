package service;

import exception.InvalidAmountException;
import model.Account;

/** Deposits 'amount' into one shared account 'times' times. */
public class AccountWorker implements Runnable {
    private final Account account;
    private final int times;
    private final long amount;
    private final boolean safe;   // true = synchronized deposit(), false = unsynchronized (race demo)

    public AccountWorker(Account account, int times, long amount, boolean safe) {
        this.account = account;
        this.times = times;
        this.amount = amount;
        this.safe = safe;
    }

    @Override
    public void run() {
        String name = Thread.currentThread().getName();
        System.out.println("  " + name + " started");
        for (int i = 0; i < times; i++) {
            try {
                if (safe) {
                    account.deposit(amount);
                } else {
                    account.depositUnsafe(amount);
                }
            } catch (InvalidAmountException e) {
                System.out.println("  " + name + " stopped: " + e.getMessage());
                return;
            }
        }
        System.out.println("  " + name + " finished");
    }
}
