package service;

import exception.BankException;
import model.Account;
import model.Command;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class TransactionProcessor {
    private final ExecutorService executor = Executors.newFixedThreadPool(4);

    // Practical 12: thread-safe map for the shared accounts
    private final ConcurrentHashMap<String, Account> accounts = new ConcurrentHashMap<>();
    private final ConcurrentLinkedQueue<String> results = new ConcurrentLinkedQueue<>();
    private final ConcurrentLinkedQueue<Command> succeeded = new ConcurrentLinkedQueue<>();

    public void register(Account account) {
        accounts.put(account.getAccountNumber(), account);
    }

    public Account get(String accountNumber) {
        return accounts.get(accountNumber);
    }

    public void submit(Runnable task) {
        executor.execute(task);
    }

    public void stop() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(30, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }

    /** Builds a Runnable that performs one deposit or withdrawal. */
    public Runnable taskFor(Command command) {
        return () -> {
            String text = command.type() + " " + command.accountNumber() + " " + command.amount();
            Account account = accounts.get(command.accountNumber());
            if (account == null) {
                results.add("FAILED  " + text + " -> account not found");
                return;
            }
            try {
                switch (command.type()) {
                    case DEPOSIT -> account.deposit(command.amount());
                    case WITHDRAW -> account.withdraw(command.amount());
                    case TRANSFER -> throw new BankException("TRANSFER needs two accounts, use the menu option");
                }
                succeeded.add(command);
                results.add("OK      " + text + " (" + Thread.currentThread().getName() + ")");
            } catch (BankException e) {
                results.add("FAILED  " + text + " -> " + e.getMessage());
            }
        };
    }

    public List<String> getResults() {
        return new ArrayList<>(results);
    }

    public List<Command> getSucceeded() {
        return new ArrayList<>(succeeded);
    }
}
