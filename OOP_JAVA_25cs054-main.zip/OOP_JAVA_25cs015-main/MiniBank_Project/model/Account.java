package model;

import exception.BankException;
import exception.InsufficientFundsException;
import exception.InvalidAmountException;
import model.annotation.Id;
import model.annotation.MaxLength;
import model.annotation.Positive;

import java.io.Serializable;
import java.util.Objects;

public abstract class Account implements Transactable, InterestBearing, Comparable<Account>, Serializable {
    private static final long serialVersionUID = 1L;
    private static long accountCounter = 0;

    @Id
    private final String accountNumber;
    @MaxLength(30)
    private String ownerName;
    @Positive
    private long balance;      // whole rupees
    private boolean active;

    // Constructor 1: owner + opening balance
    public Account(String ownerName, long openingBalance) {
        this.accountNumber = nextAccountNumber();
        this.ownerName = ownerName;
        this.balance = openingBalance;
        this.active = true;
    }

    // Constructor 2: owner only
    public Account(String ownerName) {
        this(ownerName, 0);
    }

    private static synchronized String nextAccountNumber() {
        accountCounter++;
        return String.format("AC%04d", accountCounter);   // AC0001, AC0002, ...
    }

    // Used after loading saved accounts, so new account numbers never repeat old ones
    public static synchronized void ensureCounterAtLeast(long value) {
        if (accountCounter < value) {
            accountCounter = value;
        }
    }

    // synchronized: only one thread at a time can change the balance (Practical 9)
    @Override
    public synchronized void deposit(long amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Deposit amount must be greater than zero");
        }
        balance += amount;
    }

    @Override
    public synchronized boolean withdraw(long amount) throws InsufficientFundsException, InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal amount must be greater than zero");
        }
        if (!canWithdraw(amount)) {
            long shortfall = minimumBalanceAllowed() - (balance - amount);
            throw new InsufficientFundsException(shortfall);
        }
        balance -= amount;
        return true;
    }

    // Practical 9 demo only: NOT synchronized, so the race condition can be seen
    public void depositUnsafe(long amount) {
        long current = balance;
        Thread.yield();
        balance = current + amount;
    }

    // Practical 8: try, catch, finally and re-throw
    public void transfer(Account to, long amount) throws BankException {
        try {
            withdraw(amount);
            to.deposit(amount);
        } catch (BankException e) {
            System.out.println("Transfer failed: " + e.getMessage());
            throw e;
        } finally {
            System.out.println("Transfer attempt finished");
        }
    }

    public String getAccountNumber() { return accountNumber; }
    public String getOwnerName()     { return ownerName; }
    public boolean isActive()        { return active; }

    @Override
    public synchronized long getBalance() { return balance; }

    @Override
    public abstract double interestRate();

    public abstract boolean canWithdraw(long amount);

    // Lowest balance allowed after a withdrawal (subclasses change it)
    public long minimumBalanceAllowed() {
        return 0;
    }

    @Override
    public String toString() {
        return "Account[" + accountNumber + " | " + ownerName + " | Rs. " + balance + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Account other)) return false;
        return accountNumber.equals(other.accountNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(accountNumber);
    }

    // Practical 12: natural order is by account number
    @Override
    public int compareTo(Account other) {
        return accountNumber.compareTo(other.accountNumber);
    }
}
