# MiniBank

A console banking application in Java 17+ built across Practicals 1 to 14 of the OOP lab.

## Project layout
```
MiniBank_Project/
  MiniBank.java       menu application (Practicals 1 and 14)
  Demos.java          one demo per practical (2 to 13)
  manifest.txt        Main-Class: MiniBank
  model/              Account (abstract), SavingsAccount, CurrentAccount, FixedDepositAccount,
                      Customer, Command, TransactionType, Transactable, InterestBearing,
                      WithdrawRule, Premium
  model/annotation/   @Id, @Positive, @MaxLength
  exception/          BankException, InsufficientFundsException, AccountNotFoundException,
                      InvalidAmountException
  util/               Validator, AnnotationValidator, Repository<T>
  service/            BankService, CommandParser, StatementFormatter, AccountWorker,
                      TransactionProcessor, TransactionBuffer, DeadlockDemo, TransactionSession,
                      StatePersister, TransactionLog, ReportGenerator, AccountStore
  test/BankTests.java JUnit 5 tests
```

## Build and run (PowerShell, from the project folder)
```powershell
mkdir out
javac -d out MiniBank.java Demos.java model\*.java model\annotation\*.java exception\*.java util\*.java service\*.java
java -cp out MiniBank
```

## Demos for each practical
```powershell
java -cp out Demos 9      # one practical (2 to 13)
java -cp out Demos        # all of them
```

## Runnable JAR
```powershell
"Main-Class: MiniBank" | Out-File -Encoding ascii manifest.txt
jar cfm MiniBank.jar manifest.txt -C out .
java -jar MiniBank.jar
```

## JUnit tests
```powershell
Invoke-WebRequest -Uri https://repo1.maven.org/maven2/org/junit/platform/junit-platform-console-standalone/1.10.2/junit-platform-console-standalone-1.10.2.jar -OutFile junit.jar
mkdir testout
javac -cp "out;junit.jar" -d testout test\BankTests.java
java -jar junit.jar --class-path "out;testout" --select-class BankTests
```

## Menu
| Option | What it does |
|---|---|
| OPEN_ACCOUNT | Creates a Savings, Current or Fixed Deposit account (mobile number checked with a regex) |
| DEPOSIT / WITHDRAW | Changes a balance; a failure prints a friendly message |
| TRANSFER | Moves money from one account to another |
| STATEMENT | Prints a statement for one account |
| LIST_ACCOUNTS | Lists all accounts |
| BATCH | Sends 10 deposits and 5 withdrawals to a 4-thread pool |
| REPORT | Reads the logs folder and writes report.txt with total deposits and withdrawals |
| EXIT | Saves all accounts to data/accounts.dat and quits |

Saved accounts are loaded again the next time the program starts. Transactions are appended
to logs/transactions.log.

## Account rules
| Type | Interest | Withdrawal rule |
|---|---|---|
| SavingsAccount | 4.0% | balance must stay at or above the minimum (Rs. 500 from the menu) |
| CurrentAccount | 0.0% | balance may fall to minus the overdraft limit (Rs. 5000 from the menu) |
| FixedDepositAccount | 7.0% | locked, withdrawals are always refused |

## Notes
- `balance` changes only through `deposit()`, `withdraw()` and `transfer()`. There is no setter.
- `deposit()` and `withdraw()` are `synchronized`, so many threads can share one account safely.
  `depositUnsafe()` exists only to show the race condition in Practical 9.
- `Repository<T>` finds each object's key through the `@Id` field using reflection.
