public class BoundedStats {

    static <N extends Number> double average(N[] values) {
        if (values == null || values.length == 0) {
            throw new IllegalArgumentException("Array is null or empty");
        }
        double sum = 0;
        for (N v : values) {
            sum += v.doubleValue();
        }
        return sum / values.length;
    }

    public static void main(String[] args) {
        Integer[] ints  = {10, 20, 30, 40};
        Double[]  dbls  = {1.5, 2.5, 3.5};
        Long[]    longs = {1_000_000_000_000L, 2_000_000_000_000L};

        System.out.println(average(ints));    
        System.out.println(average(dbls));    
        System.out.println(average(longs));   

        
    }
}