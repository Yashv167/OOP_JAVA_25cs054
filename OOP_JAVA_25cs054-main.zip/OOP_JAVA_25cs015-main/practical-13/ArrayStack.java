import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Optional;

public class ArrayStack {

    // Generic stack backed by an array that grows when full
    static class ArrayStack<T> {
        private T[] items;
        private int size;

        @SuppressWarnings("unchecked")
        public ArrayStack(int capacity) {
            if (capacity < 1) {
                throw new IllegalArgumentException("Capacity must be at least 1");
            }
            items = (T[]) new Object[capacity];   // generic arrays can't be created directly
        }

        public void push(T item) {
            if (size == items.length) {
                items = Arrays.copyOf(items, size * 2);   // double the capacity
            }
            items[size++] = item;
        }

        // Throws on empty: there is no sensible value to return
        public T pop() {
            if (isEmpty()) {
                throw new NoSuchElementException("Stack is empty");
            }
            T item = items[--size];
            items[size] = null;   // drop the reference so it can be garbage collected
            return item;
        }

        public T peek() {
            if (isEmpty()) {
                throw new NoSuchElementException("Stack is empty");
            }
            return items[size - 1];
        }

        // Non-throwing alternative for callers who expect emptiness
        public Optional<T> tryPop() {
            return isEmpty() ? Optional.empty() : Optional.of(pop());
        }

        public boolean isEmpty() { return size == 0; }
        public int size()        { return size; }
    }

    public static void main(String[] args) {
        // Stack of Integer (starts at capacity 2, so the third push triggers growth)
        ArrayStack<Integer> nums = new ArrayStack<>(2);
        nums.push(10);
        nums.push(20);
        nums.push(30);
        System.out.println("peek=" + nums.peek() + ", size=" + nums.size());
        int sum = 0;
        while (!nums.isEmpty()) {
            sum += nums.pop();            // Integer auto-unboxed, no cast
        }
        System.out.println("sum=" + sum);

        // Same class, different type: Stack of String
        ArrayStack<String> words = new ArrayStack<>(4);
        words.push("one");
        words.push("two");
        words.push("three");
        while (!words.isEmpty()) {
            System.out.print(words.pop().toUpperCase() + " ");   // String methods, no cast
        }
        System.out.println();

        // nums.push("text");   // compile error: String cannot be converted to Integer

        // Empty case, two ways
        try {
            nums.pop();
        } catch (NoSuchElementException e) {
            System.out.println("Caught: " + e.getMessage());
        }
        System.out.println(words.tryPop().isPresent());                 // false
        System.out.println(words.tryPop().orElse("(nothing)"));         // (nothing)
    }
}