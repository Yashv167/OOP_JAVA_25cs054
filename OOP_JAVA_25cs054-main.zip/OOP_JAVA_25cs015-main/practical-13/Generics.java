public class Generics {

    static class Box<T> {
        private T value;

        public Box(T value) { this.value = value; }
        public T get()      { return value; }
        public void set(T value) { this.value = value; }

        @Override public String toString() { return "Box[" + value + "]"; }
    }

    static class Pair<A, B> {
        private final A first;
        private final B second;

        public Pair(A first, B second) {
            this.first = first;
            this.second = second;
        }
        public A getFirst()  { return first; }
        public B getSecond() { return second; }

        @Override public String toString() { return "(" + first + ", " + second + ")"; }
    }

    static <T> T firstElement(T[] arr) {
        if (arr == null || arr.length == 0) {
            throw new IllegalArgumentException("Array is null or empty");
        }
        return arr[0];
    }

    public static void main(String[] args) {
        Box<Integer> intBox = new Box<>(42);
        int total = intBox.get() + 8;
        System.out.println(intBox + " -> " + total);

        Box<String> strBox = new Box<>("hello");
        System.out.println(strBox.get().toUpperCase());
        strBox.set("world");
        System.out.println(strBox);


        Pair<String, Integer> player = new Pair<>("Asha", 920);
        String name = player.getFirst();
        int score = player.getSecond();
        System.out.println(name + " scored " + score);

        Pair<Double, Boolean> reading = new Pair<>(3.14, true);
        System.out.println(reading);

        Box<Pair<String, Integer>> boxedPair = new Box<>(player);
        System.out.println(boxedPair.get().getFirst().length());

        String[] names = {"Asha", "Ravi", "Meera"};
        Integer[] nums = {10, 20, 30};
        String firstName = firstElement(names);   
        Integer firstNum = firstElement(nums);    
        System.out.println(firstName + " " + firstNum);
    }
}