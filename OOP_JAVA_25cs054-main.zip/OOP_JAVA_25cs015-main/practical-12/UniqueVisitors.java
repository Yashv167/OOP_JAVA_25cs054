import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class UniqueVisitors {
    public static void main(String[] args) {
        List<String> logins = List.of(
            "asha", "ravi", "asha", "neha", "karan",
            "ravi", "mira", "asha", "neha", "dev"
        );

        Set<String> unique = new HashSet<>(logins);

        Set<String> firstSeen = new LinkedHashSet<>(logins);

        System.out.println("Total logins:          " + logins.size());
        System.out.println("Unique users (HashSet): " + unique.size());
        System.out.println("Repeat logins:         " + (logins.size() - unique.size()));
        System.out.println("Distinct, first-seen:  " + firstSeen);

        List<String> firstThree = new ArrayList<>();
        for (String name : firstSeen) {
            if (firstThree.size() == 3) break;
            firstThree.add(name);
        }
        System.out.println("First three distinct:  " + firstThree);
    }
}