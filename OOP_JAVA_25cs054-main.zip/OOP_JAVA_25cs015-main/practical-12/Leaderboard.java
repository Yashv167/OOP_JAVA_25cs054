import java.util.*;
import java.util.stream.*;

public class Leaderboard {
    public static void main(String[] args) {
        Map<String, Integer> scores = new HashMap<>();
        scores.put("Asha", 920);
        scores.put("Ravi", 850);
        scores.put("Meera", 920);
        scores.put("Kabir", 780);
        scores.put("Zoya", 850);
        scores.put("Dev", 910);
        scores.put("Isha", 700);
        scores.put("Neel", 850);

        int n = 5;

        Comparator<Map.Entry<String, Integer>> byScoreThenName =
            Map.Entry.<String, Integer>comparingByValue(Comparator.reverseOrder())
                     .thenComparing(Map.Entry.comparingByKey());

        List<Map.Entry<String, Integer>> top = scores.entrySet().stream()
            .sorted(byScoreThenName)
            .limit(n)
            .collect(Collectors.toList());

        System.out.printf("Top %d players%n", n);
        System.out.println("-".repeat(24));
        int rank = 1;
        for (Map.Entry<String, Integer> e : top) {
            System.out.printf("%2d. %-8s %4d%n", rank++, e.getKey(), e.getValue());
        }
    }
}