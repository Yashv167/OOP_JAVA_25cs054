import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WordFrequency {
    public static void main(String[] args) {
        String paragraph = "The quick brown fox jumps over the lazy dog. "
                         + "The dog barks, and the fox runs away. "
                         + "A quick fox is a happy fox!";

        String[] words = paragraph.toLowerCase().split("[^a-z']+");

        Map<String, Integer> counts = new HashMap<>();
        int total = 0;
        for (String w : words) {
            if (w.isEmpty()) continue;            
            counts.merge(w, 1, Integer::sum);     
            total++;
        }

        List<Map.Entry<String, Integer>> entries = new ArrayList<>(counts.entrySet());

        Comparator<Map.Entry<String, Integer>> byFrequency = (a, b) -> {
            int byCount = Integer.compare(b.getValue(), a.getValue());   
            if (byCount != 0) return byCount;
            return a.getKey().compareTo(b.getKey());                     
        };
        entries.sort(byFrequency);

        System.out.println("Total words: " + total + ", unique words: " + counts.size());
        System.out.println();

        int rank = 1;
        for (Map.Entry<String, Integer> e : entries) {
            System.out.printf("%2d. %-6s %d%n", rank++, e.getKey(), e.getValue());
        }
    }
}