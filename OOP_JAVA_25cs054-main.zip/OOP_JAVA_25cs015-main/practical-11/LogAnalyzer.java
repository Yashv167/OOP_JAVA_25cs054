import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class LogAnalyzer {

    static void write(Path dir, String name, String... lines) throws IOException {
        Files.writeString(dir.resolve(name), String.join("\n", lines) + "\n");
    }

    static void createSampleLogs(Path dir) throws IOException {
        write(dir, "app.log",
            "INFO  server started",
            "INFO  user login ok",
            "ERROR payment failed",
            "WARN  slow response",
            "ERROR timeout on gateway");
        write(dir, "db.log",
            "INFO  connection pool ready",
            "ERROR deadlock detected",
            "INFO  query ok");
        write(dir, "web.log",
            "INFO  GET /index 200",
            "INFO  GET /about 200",
            "WARN  GET /old 301",
            "ERROR GET /admin 500",
            "INFO  GET /contact 200",
            "INFO  no errors today");        
    }

    static void deleteAll(Path dir) throws IOException {
        try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir)) {
            for (Path p : ds) Files.deleteIfExists(p);
        }
        Files.deleteIfExists(dir);
    }

    public static void main(String[] args) throws IOException {
        final String keyword = "ERROR";
        Path dir = Files.createTempDirectory("logs");

        try {
            createSampleLogs(dir);

            List<Path> files = new ArrayList<>();
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.log")) {
                for (Path p : ds) files.add(p);
            }
            files.sort(Comparator.comparing(p -> p.getFileName().toString()));

            int totalLines = 0, totalMatches = 0;
            long totalBytes = 0;

            System.out.printf("%-8s %6s %7s %9s%n", "File", "Bytes", "Lines", "Matches");

            for (Path file : files) {
                int lines = 0, matches = 0;

                try (BufferedReader reader = Files.newBufferedReader(file)) {   
                    String line;
                    while ((line = reader.readLine()) != null) {
                        lines++;
                        if (line.contains(keyword)) matches++;
                    }
                }

                BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
                long bytes = attrs.size();

                System.out.printf("%-8s %6d %7d %9d%n",
                                  file.getFileName(), bytes, lines, matches);

                totalLines += lines;
                totalMatches += matches;
                totalBytes += bytes;
            }

            System.out.println();
            System.out.println("Total: " + totalLines + " lines, " + totalBytes
                               + " bytes across " + files.size() + " files");
            System.out.println("Lines containing \"" + keyword + "\": " + totalMatches);
            System.out.printf("Share of lines: %.1f%%%n", 100.0 * totalMatches / totalLines);
        } finally {
            deleteAll(dir);                       
        }
    }
}