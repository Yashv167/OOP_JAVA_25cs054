import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Student implements Serializable {
    private static final long serialVersionUID = 1L;   

    private final String name;
    private final int marks;
    private final double gpa;
    private transient String password;                 

    Student(String name, int marks, double gpa, String password) {
        this.name = name;
        this.marks = marks;
        this.gpa = gpa;
        this.password = password;
    }

    String getName()     { return name; }
    int getMarks()       { return marks; }
    double getGpa()      { return gpa; }
    String getPassword() { return password; }

    @Override
    public String toString() {
        return "Student{name=" + name + ", marks=" + marks + ", gpa=" + gpa
               + ", password=" + password + "}";
    }
}

public class SaveLoad {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Student[] original = {
            new Student("Asha", 92, 9.1, "asha123"),
            new Student("Ravi", 78, 7.4, "r@vi99"),
            new Student("Neha", 85, 8.2, "neha#1")
        };

        File file = File.createTempFile("students", ".ser");
        try {
            try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
                out.writeObject(original);
            }
            System.out.println("Saved " + original.length + " students");

            Student[] loaded;
            try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
                loaded = (Student[]) in.readObject();
            }

            System.out.println("\nOriginal:");
            for (Student s : original) System.out.println("  " + s);

            System.out.println("\nLoaded:");
            for (Student s : loaded) System.out.println("  " + s);

            boolean allFresh = true, allMatch = true, allPasswordsGone = true;
            for (int i = 0; i < original.length; i++) {
                Student o = original[i], l = loaded[i];
                if (o == l) allFresh = false;
                if (!o.getName().equals(l.getName())
                        || o.getMarks() != l.getMarks()
                        || o.getGpa() != l.getGpa()) {
                    allMatch = false;
                }
                if (l.getPassword() != null) allPasswordsGone = false;
            }

            System.out.println();
            System.out.println("Loaded objects are new instances: " + allFresh);
            System.out.println("name, marks and gpa all survived: " + allMatch);
            System.out.println("transient password was not saved: " + allPasswordsGone);
        } finally {
            file.delete();                                  
        }
    }
}