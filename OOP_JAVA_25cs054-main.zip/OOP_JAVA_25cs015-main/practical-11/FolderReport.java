import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.stream.Stream;

public class FolderReport {

    record FileInfo(String path, long size, Instant modified) {}

    static class ScanResult {
        final List<FileInfo> files = new ArrayList<>();
        final List<String> skipped = new ArrayList<>();
        int folders = 0;
        int unreadable = 0;
    }

    static final Set<String> SKIP_DIRS = Set.of(".git", "node_modules");
    static final DateTimeFormatter TIME =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneOffset.UTC);


    static ScanResult scan(Path root, Path reportPath) throws IOException {
        ScanResult result = new ScanResult();

        Files.walkFileTree(root, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
                if (!dir.equals(root)) {
                    if (SKIP_DIRS.contains(dir.getFileName().toString())) {
                        result.skipped.add(root.relativize(dir).toString().replace('\\', '/'));
                        return FileVisitResult.SKIP_SUBTREE;      
                    }
                    result.folders++;
                }
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
                if (!attrs.isRegularFile()) {                      
                    return FileVisitResult.CONTINUE;
                }
                if (file.toAbsolutePath().normalize().equals(reportPath)) {
                    return FileVisitResult.CONTINUE;               
                }
                String rel = root.relativize(file).toString().replace('\\', '/');
                // attrs came with the visit, so no extra disk call per file
                result.files.add(new FileInfo(rel, attrs.size(), attrs.lastModifiedTime().toInstant()));
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult visitFileFailed(Path file, IOException exc) {
                result.unreadable++;                               
                return FileVisitResult.CONTINUE;
            }
        });

        result.files.sort(Comparator.comparing(FileInfo::path));   
        return result;
    }


    static String human(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double kb = bytes / 1024.0;
        if (kb < 1024) return String.format(Locale.ROOT, "%.1f KB", kb);
        return String.format(Locale.ROOT, "%.1f MB", kb / 1024.0);
    }

    static String extension(String path) {
        String name = path.substring(path.lastIndexOf('/') + 1);
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(dot).toLowerCase(Locale.ROOT) : "(none)";
    }

    static void line(StringBuilder sb, String label, String value) {
        sb.append(String.format(Locale.ROOT, "%-9s%s\n", label, value));
    }

    static String buildReport(Path root, ScanResult r) {
        StringBuilder sb = new StringBuilder();
        sb.append("FOLDER REPORT\n");
        sb.append("Root: ").append(root.getFileName()).append('\n');
        sb.append("All times are UTC\n\n");

        if (r.files.isEmpty()) {
            sb.append("No files found.\n");
            return sb.toString();
        }

        long total = 0;
        FileInfo largest = null, newest = null, oldest = null;
        Map<String, long[]> byExt = new TreeMap<>();               

        for (FileInfo f : r.files) {
            total += f.size();
            if (largest == null || f.size() > largest.size()) largest = f;
            if (newest == null || f.modified().isAfter(newest.modified())) newest = f;
            if (oldest == null || f.modified().isBefore(oldest.modified())) oldest = f;
            long[] s = byExt.computeIfAbsent(extension(f.path()), k -> new long[2]);
            s[0]++;
            s[1] += f.size();
        }

        sb.append("SUMMARY\n");
        line(sb, "Files:", String.valueOf(r.files.size()));
        line(sb, "Folders:", r.folders + " (excluding root)");
        line(sb, "Total:", total + " bytes (" + human(total) + ")");
        line(sb, "Largest:", largest.path() + " (" + human(largest.size()) + ")");
        line(sb, "Newest:", newest.path() + " (" + TIME.format(newest.modified()) + ")");
        line(sb, "Oldest:", oldest.path() + " (" + TIME.format(oldest.modified()) + ")");
        if (!r.skipped.isEmpty()) line(sb, "Skipped:", String.join(", ", r.skipped));
        if (r.unreadable > 0)     line(sb, "Errors:", r.unreadable + " unreadable entries");

        sb.append("\nBY EXTENSION\n");
        sb.append(String.format(Locale.ROOT, "%-8s %5s %10s\n", "Type", "Files", "Bytes"));
        for (Map.Entry<String, long[]> e : byExt.entrySet()) {
            sb.append(String.format(Locale.ROOT, "%-8s %5d %10d\n",
                                    e.getKey(), e.getValue()[0], e.getValue()[1]));
        }

        sb.append("\nFILES\n");
        sb.append(String.format(Locale.ROOT, "%12s  %-16s  %s\n", "Size (bytes)", "Modified (UTC)", "Path"));
        for (FileInfo f : r.files) {
            sb.append(String.format(Locale.ROOT, "%12d  %s  %s\n",
                                    f.size(), TIME.format(f.modified()), f.path()));
        }
        return sb.toString();
    }


    static void file(Path root, String rel, int size, String modified) throws IOException {
        Path p = root.resolve(rel);
        Files.createDirectories(p.getParent());
        Files.write(p, new byte[size]);
        Files.setLastModifiedTime(p, FileTime.from(Instant.parse(modified)));
    }

    static Path createSampleTree(Path base) throws IOException {
        Path root = Files.createDirectory(base.resolve("project"));
        file(root, "README.md",             1200,   "2026-01-10T09:00:00Z");
        file(root, "notes",                  120,   "2026-02-14T16:40:00Z");
        file(root, "src/Main.java",         2048,   "2026-03-15T14:30:00Z");
        file(root, "src/util/Helper.java",   850,   "2026-02-01T08:15:00Z");
        file(root, "src/util/Strings.java", 3100,   "2026-04-20T17:45:00Z");
        file(root, "docs/guide.txt",        5000,   "2026-01-25T11:00:00Z");
        file(root, "docs/img/logo.png",    15360,   "2025-12-05T10:20:00Z");
        file(root, "build/output.jar",    204800,   "2026-04-21T09:05:00Z");
        file(root, ".git/config",             90,   "2026-01-01T00:00:00Z");   
        Files.createDirectories(root.resolve("docs/empty"));
        return root;
    }

    static void deleteTree(Path dir) throws IOException {
        try (Stream<Path> walk = Files.walk(dir)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete()); 
        }
    }


    public static void main(String[] args) throws IOException {
        boolean demo = args.length == 0;
        Path base = demo ? Files.createTempDirectory("report-demo") : null;
        Path root = demo ? createSampleTree(base) : Path.of(args[0]);
        Path reportPath = (demo ? base.resolve("report.txt") : Path.of("folder-report.txt"))
                              .toAbsolutePath().normalize();
        try {
            if (!Files.isDirectory(root)) {
                System.out.println("Not a folder: " + root);
                return;
            }
            ScanResult result = scan(root, reportPath);
            Files.writeString(reportPath, buildReport(root, result));

            System.out.println("Report written to "
                + (demo ? "a temporary file (deleted afterwards)" : reportPath) + ":\n");
            System.out.print(Files.readString(reportPath));      
        } finally {
            if (demo) deleteTree(base);
        }
    }
}